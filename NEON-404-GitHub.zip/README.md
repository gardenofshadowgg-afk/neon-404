# NEON 404 — Invasão dos Circuitos

Jogo retrô de ação em primeira pessoa (FPS), com robôs e cinco setores, criado em **HTML, CSS e JavaScript puro**. Não usa bibliotecas, CDNs, APIs, login nem recursos externos.

## O que vem no jogo

- 5 setores procedurais, cada um com uma paleta de cores e um mapa conectado.
- Robôs de diferentes categorias e um chefe na última fase.
- 3 armas: blaster com disparos infinitos, espalhador e plasma.
- Itens coletáveis: cristais, vida, energia de armas e desbloqueios.
- Radar, pontuação, vida, recuo da arma e sons gerados no próprio aparelho.
- Joystick virtual, mira por arrasto na tela e botões para atirar/trocar arma.
- Salva o progresso localmente **a cada setor concluído** (localStorage).
- PWA com Service Worker para jogar offline após o primeiro carregamento completo.

## Publicar gratuitamente no GitHub Pages

1. Entre em https://github.com/new e crie um repositório chamado `neon-404`.
2. Descompacte o arquivo `NEON-404-GitHub.zip` em seu computador ou celular.
3. No repositório, escolha **Add file > Upload files** e envie **os arquivos e a pasta `icons`**, sem colocar tudo dentro de uma pasta `neon404`. O arquivo `index.html` precisa estar na raiz.
4. Confirme em **Commit changes**.
5. Em **Settings > Pages**, escolha **Deploy from a branch**, `main` e `/ (root)` e salve.
6. Aguarde o GitHub publicar e abra o endereço de Pages que aparecer, normalmente `https://SEU-USUARIO.github.io/neon-404/`.

**Importante:** não envie somente o ZIP ao repositório. Os arquivos precisam ser extraídos.

## Testar sem internet no Android

1. Abra a página do jogo no Chrome com internet, aguarde alguns segundos para os arquivos serem armazenados.
2. No menu do Chrome, procure **Instalar aplicativo** ou **Adicionar à tela inicial**.
3. Depois de abrir o jogo pelo menos uma vez, ative o **modo avião** e abra o atalho instalado.
4. O jogo deve funcionar offline. O primeiro carregamento online é necessário para que o navegador registre o Service Worker e armazene os arquivos.

A página precisa estar em HTTPS (GitHub Pages atende). O modo privado/anônimo, os limites de armazenamento do navegador e a limpeza dos dados do site podem apagar o progresso ou o cache offline.

## Controles

**Celular:** controle esquerdo para andar, deslizar à direita para olhar, **DISPARAR** para atirar, **ARMA** para trocar e botão `Ⅱ` para pausa.

**PC:** W A S D para andar, setas esquerda/direita para olhar, mouse para mirar (clique para capturar), clique ou espaço para atirar, teclas 1/2/3 para armas, M para radar e Esc para pausar.

**Objetivo:** neutralizar todos os robôs de um setor e chegar ao portal de saída. O portal fica no canto oposto do mapa. Pegue itens no caminho.

## Estrutura

```
index.html
style.css
game.js
manifest.webmanifest
sw.js
icons/
  icon-192.png
  icon-512.png
README.md
```

## Uso e evolução

Este é um **protótipo jogável para teste**, não um APK nem uma versão pronta para a Play Store. Para publicar na Play Store futuramente, será necessário empacotar o jogo como app Android (por exemplo, por TWA ou WebView) e revisar requisitos da loja, funcionamento offline, desempenho, interface e testes em diferentes aparelhos.

Projeto original criado como base para desenvolvimento e testes. Sem dependências de terceiros.
